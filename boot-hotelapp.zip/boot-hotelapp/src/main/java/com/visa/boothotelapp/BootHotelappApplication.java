package com.visa.boothotelapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootHotelappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootHotelappApplication.class, args);
	}

}
